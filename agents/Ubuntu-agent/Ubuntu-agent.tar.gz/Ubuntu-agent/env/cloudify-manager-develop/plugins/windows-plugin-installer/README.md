cloudify-windows-plugin-installer-plugin
=========================================

Cloudify plugin for installing additional plugins on windows machines.

